# GitOps Helm Repo for Argo CD

This sample repository shows how to keep **your own Helm charts in your own GitHub repo**
and deploy them with **Argo CD** to an external EKS cluster.

It uses:
- one repo
- one chart per app
- one environment values file per cluster/environment
- one Argo CD Application per app
- no ApplicationSet

## Replace these placeholders before use

- `YOUR_GITHUB_REPO_URL`
- `TARGET_CLUSTER_API_SERVER`

## Suggested usage

1. Push this repo to GitHub.
2. Replace placeholders in:
   - `projects/eks-oidc-test-project.yaml`
   - `apps/nginx-application.yaml`
   - `apps/tomcat-application.yaml`
3. Apply the AppProject:
   ```bash
   kubectl apply -f projects/eks-oidc-test-project.yaml -n argocd
   ```
4. Apply one app:
   ```bash
   kubectl apply -f apps/nginx-application.yaml -n argocd
   ```
5. Verify:
   ```bash
   argocd app list
   argocd app get nginx-eks-oidc-test
   ```

## Repo layout

```text
gitops-helm-own-repo/
├── apps/
│   ├── nginx-application.yaml
│   └── tomcat-application.yaml
├── charts/
│   ├── nginx-app/
│   │   ├── Chart.yaml
│   │   ├── values.yaml
│   │   └── templates/
│   │       ├── _helpers.tpl
│   │       ├── deployment.yaml
│   │       ├── service.yaml
│   │       └── ingress.yaml
│   └── tomcat-app/
│       ├── Chart.yaml
│       ├── values.yaml
│       └── templates/
│           ├── _helpers.tpl
│           ├── deployment.yaml
│           ├── service.yaml
│           └── ingress.yaml
├── environments/
│   └── eks-oidc-test/
│       ├── nginx-values.yaml
│       └── tomcat-values.yaml
└── projects/
│   └── eks-oidc-test-project.yaml
```

## Updating versions

To deploy a new app version, update:
- `environments/eks-oidc-test/nginx-values.yaml`
- or `environments/eks-oidc-test/tomcat-values.yaml`

Example:
```yaml
image:
  tag: "1.27.1"
```

Then commit and push. Argo CD will sync the change.
