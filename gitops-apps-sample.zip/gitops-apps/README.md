# GitOps Apps Sample Repo for Argo CD

This sample repo demonstrates a **single Git repository for multiple applications**
deployed by **Argo CD** to an external EKS cluster.

Included:
- `projects/` - Argo CD AppProject definitions
- `apps/nginx/` - Sample NGINX Helm-based app
- `apps/tomcat/` - Sample Tomcat Helm-based app
- `appsets/` - Optional ApplicationSet example

## Repo layout

```text
gitops-apps/
├── apps/
│   ├── nginx/
│   │   ├── application.yaml
│   │   └── values/
│   │       ├── values-common.yaml
│   │       └── values-eks-oidc-test.yaml
│   └── tomcat/
│       ├── application.yaml
│       └── values/
│           ├── values-common.yaml
│           └── values-eks-oidc-test.yaml
├── projects/
│   └── eks-oidc-test-project.yaml
└── appsets/
│   └── apps-to-eks-oidc-test.yaml
```

## How to use

1. Replace these placeholders in the YAML files:
   - `YOUR_GITHUB_REPO_URL`
   - `TARGET_CLUSTER_API_SERVER`
2. Push this repo to GitHub.
3. Apply the project:
   ```bash
   kubectl apply -f projects/eks-oidc-test-project.yaml
   ```
4. Apply one app:
   ```bash
   kubectl apply -f apps/nginx/application.yaml
   ```
   or
   ```bash
   kubectl apply -f apps/tomcat/application.yaml
   ```

## Notes

- This repo uses **multiple sources** in Argo CD:
  - Helm chart from Bitnami
  - values files from this Git repo
- You can keep **multiple applications in a single repo**.
- `CreateNamespace=true` is enabled in the sample Applications.
